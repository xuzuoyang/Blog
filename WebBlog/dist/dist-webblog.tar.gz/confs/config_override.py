configs = {
    'db': {
        'host': '127.0.0.1'
    }
}